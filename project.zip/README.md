# Lizard N Roaches

## How to run

### Compiling

Enter the root directory and run the make command:

```
make all
```

this will compile everything and output all of it into the "outputs" folder

### Running

To run, create a terminal and enter at the output folder

To run the server execute:

```
./lizardsNroaches-server
```

To run the lizard client execute:

```
./lizard-client
```

To run the roaches client execute:

```
./roaches-client
```

And finally to run the display:

```
./display-app
```
